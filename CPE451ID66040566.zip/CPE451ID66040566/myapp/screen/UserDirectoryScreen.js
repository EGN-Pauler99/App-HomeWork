import { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

import UserCard from '../components/UserCard';
import { getUsers } from '../service/userService';

export default function UserDirectoryScreen() {
  const [users, setUsers] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [expandedUserId, setExpandedUserId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  async function loadUsers(isRefresh = false) {
    try {
      setError('');
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      const nextUsers = await getUsers();
      setUsers(nextUsers);
    } catch (nextError) {
      setError(nextError.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    loadUsers();
  }, []);

  const filteredUsers = useMemo(() => {
    const keyword = searchText.trim().toLowerCase();

    if (!keyword) {
      return users;
    }

    return users.filter((user) => {
      const fullName = `${user.firstName} ${user.lastName}`.toLowerCase();
      return fullName.includes(keyword) || user.email.toLowerCase().includes(keyword);
    });
  }, [searchText, users]);

  function toggleUserDetails(userId) {
    setExpandedUserId((currentId) => (currentId === userId ? null : userId));
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.hero}>
          <View style={styles.heroText}>
            <Text style={styles.kicker}>DummyJSON API</Text>
            <Text style={styles.title}>User Directory</Text>
            <Text style={styles.subtitle}>
              Search, refresh, and tap users to view details.
            </Text>
          </View>
          <View style={styles.countBadge}>
            <Text style={styles.countNumber}>{filteredUsers.length}</Text>
            <Text style={styles.countLabel}>users</Text>
          </View>
        </View>

        <View style={styles.toolbar}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search by name or email"
            placeholderTextColor="#8794a5"
            value={searchText}
            onChangeText={setSearchText}
          />

          <Pressable
            style={({ pressed }) => [
              styles.refreshButton,
              pressed && styles.refreshButtonPressed,
            ]}
            onPress={() => loadUsers(true)}
          >
            <Text style={styles.refreshButtonText}>
              {refreshing ? 'Wait' : 'Refresh'}
            </Text>
          </Pressable>
        </View>

        {loading ? (
          <View style={styles.centerBox}>
            <ActivityIndicator color="#126f72" size="large" />
            <Text style={styles.loadingText}>Loading users...</Text>
          </View>
        ) : (
          <FlatList
            data={filteredUsers}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <UserCard
                user={item}
                expanded={expandedUserId === item.id}
                onPress={() => toggleUserDetails(item.id)}
              />
            )}
            refreshing={refreshing}
            onRefresh={() => loadUsers(true)}
            ListEmptyComponent={
              <Text style={styles.emptyText}>No users found.</Text>
            }
            ListHeaderComponent={
              error ? <Text style={styles.errorText}>{error}</Text> : null
            }
            contentContainerStyle={styles.listContent}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: '#f4f7f6',
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 18,
  },
  hero: {
    alignItems: 'center',
    backgroundColor: '#126f72',
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 14,
    padding: 18,
  },
  heroText: {
    flex: 1,
    paddingRight: 12,
  },
  kicker: {
    color: '#bfe8e2',
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 0,
    textTransform: 'uppercase',
  },
  title: {
    color: '#ffffff',
    fontSize: 28,
    fontWeight: '900',
    marginTop: 4,
  },
  subtitle: {
    color: '#e8fffb',
    fontSize: 13,
    lineHeight: 18,
    marginTop: 5,
  },
  countBadge: {
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 8,
    minWidth: 68,
    padding: 10,
  },
  countNumber: {
    color: '#126f72',
    fontSize: 24,
    fontWeight: '900',
  },
  countLabel: {
    color: '#5f6c7b',
    fontSize: 12,
    fontWeight: '800',
  },
  toolbar: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 12,
  },
  searchInput: {
    backgroundColor: '#ffffff',
    borderColor: '#dce5e4',
    borderRadius: 7,
    borderWidth: 1,
    flex: 1,
    fontSize: 15,
    height: 46,
    paddingHorizontal: 12,
  },
  refreshButton: {
    alignItems: 'center',
    backgroundColor: '#102a43',
    borderRadius: 7,
    height: 46,
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  refreshButtonPressed: {
    opacity: 0.82,
  },
  refreshButtonText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '800',
  },
  centerBox: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },
  loadingText: {
    color: '#5f6c7b',
    marginTop: 10,
  },
  listContent: {
    paddingBottom: 24,
  },
  emptyText: {
    color: '#5f6c7b',
    fontSize: 15,
    paddingTop: 24,
    textAlign: 'center',
  },
  errorText: {
    color: '#b42318',
    fontSize: 14,
    marginBottom: 10,
  },
});
