import { SafeAreaView, StyleSheet, Text, View } from 'react-native';

const requirements = [
  'Fetch users from DummyJSON API',
  'Search by name or email',
  'Tap a user card to show age, gender, address, and company',
  'Refresh data and show loading state',
  'Use React Native components and StyleSheet',
];

export default function InfoScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.hero}>
          <Text style={styles.kicker}>Assignment 2</Text>
          <Text style={styles.title}>User Directory App</Text>
          <Text style={styles.subtitle}>
            A clean React Native app with tabs, live API data, search, refresh,
            and expandable user details.
          </Text>
        </View>

        <View style={styles.panel}>
          <Text style={styles.panelTitle}>Completed Features</Text>
          {requirements.map((item) => (
            <View style={styles.requirementRow} key={item}>
              <Text style={styles.check}>OK</Text>
              <Text style={styles.requirementText}>{item}</Text>
            </View>
          ))}
        </View>

        <View style={styles.apiBox}>
          <Text style={styles.apiLabel}>API Source</Text>
          <Text style={styles.apiText}>https://dummyjson.com/users</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: '#f4f7f6',
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 18,
  },
  hero: {
    backgroundColor: '#126f72',
    borderRadius: 8,
    marginBottom: 16,
    padding: 22,
  },
  kicker: {
    color: '#bfe8e2',
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 0,
    textTransform: 'uppercase',
  },
  title: {
    color: '#ffffff',
    fontSize: 30,
    fontWeight: '900',
    marginTop: 8,
  },
  subtitle: {
    color: '#e8fffb',
    fontSize: 15,
    lineHeight: 22,
    marginTop: 8,
  },
  panel: {
    backgroundColor: '#ffffff',
    borderColor: '#dce5e4',
    borderRadius: 8,
    borderWidth: 1,
    padding: 16,
  },
  panelTitle: {
    color: '#102a43',
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 12,
  },
  requirementRow: {
    alignItems: 'center',
    flexDirection: 'row',
    marginBottom: 12,
  },
  check: {
    backgroundColor: '#d8f1ee',
    borderRadius: 6,
    color: '#126f72',
    fontSize: 11,
    fontWeight: '900',
    marginRight: 10,
    overflow: 'hidden',
    paddingHorizontal: 7,
    paddingVertical: 4,
  },
  requirementText: {
    color: '#334155',
    flex: 1,
    fontSize: 14,
  },
  apiBox: {
    backgroundColor: '#102a43',
    borderRadius: 8,
    marginTop: 16,
    padding: 16,
  },
  apiLabel: {
    color: '#9de1db',
    fontSize: 12,
    fontWeight: '900',
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  apiText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '700',
  },
});
