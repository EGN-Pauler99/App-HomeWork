import { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import StatCard from '../components/StatCard';
import { getUsers } from '../service/userService';

export default function UserStatsScreen() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function loadUsers() {
    try {
      setError('');
      setLoading(true);
      const nextUsers = await getUsers();
      setUsers(nextUsers);
    } catch (nextError) {
      setError(nextError.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadUsers();
  }, []);

  const summary = useMemo(() => {
    const femaleCount = users.filter((user) => user.gender === 'female').length;
    const maleCount = users.filter((user) => user.gender === 'male').length;
    const companies = new Set(users.map((user) => user.company?.name).filter(Boolean));

    return {
      femaleCount,
      maleCount,
      companyCount: companies.size,
    };
  }, [users]);

  const companyList = useMemo(
    () =>
      users.slice(0, 8).map((user) => ({
        id: user.id,
        name: `${user.firstName} ${user.lastName}`,
        company: user.company?.name || 'No company',
        department: user.company?.department || 'General',
      })),
    [users]
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.kicker}>Directory Insight</Text>
          <Text style={styles.title}>User Stats</Text>
          <Text style={styles.subtitle}>Quick overview from DummyJSON users.</Text>
        </View>

        {loading ? (
          <View style={styles.centerBox}>
            <ActivityIndicator color="#126f72" size="large" />
            <Text style={styles.loadingText}>Loading stats...</Text>
          </View>
        ) : (
          <FlatList
            data={companyList}
            keyExtractor={(item) => item.id.toString()}
            ListHeaderComponent={
              <View>
                {error ? <Text style={styles.errorText}>{error}</Text> : null}
                <View style={styles.statRow}>
                  <StatCard label="Users" value={users.length} />
                  <StatCard label="Companies" value={summary.companyCount} tone="blue" />
                </View>
                <View style={styles.statRow}>
                  <StatCard label="Female" value={summary.femaleCount} tone="rose" />
                  <StatCard label="Male" value={summary.maleCount} />
                </View>
                <View style={styles.sectionHeader}>
                  <Text style={styles.sectionTitle}>Companies</Text>
                  <Pressable style={styles.smallButton} onPress={loadUsers}>
                    <Text style={styles.smallButtonText}>Refresh</Text>
                  </Pressable>
                </View>
              </View>
            }
            renderItem={({ item }) => (
              <View style={styles.companyRow}>
                <View>
                  <Text style={styles.companyName}>{item.company}</Text>
                  <Text style={styles.companyMeta}>{item.name}</Text>
                </View>
                <Text style={styles.department}>{item.department}</Text>
              </View>
            )}
            contentContainerStyle={styles.listContent}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: '#f4f7f6',
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 18,
  },
  header: {
    marginBottom: 16,
  },
  kicker: {
    color: '#126f72',
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 0,
    textTransform: 'uppercase',
  },
  title: {
    color: '#102a43',
    fontSize: 30,
    fontWeight: '900',
    marginTop: 4,
  },
  subtitle: {
    color: '#5f6c7b',
    fontSize: 14,
    marginTop: 4,
  },
  centerBox: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },
  loadingText: {
    color: '#5f6c7b',
    marginTop: 10,
  },
  statRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 10,
  },
  sectionHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    marginTop: 10,
  },
  sectionTitle: {
    color: '#102a43',
    fontSize: 18,
    fontWeight: '900',
  },
  smallButton: {
    backgroundColor: '#126f72',
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  smallButtonText: {
    color: '#ffffff',
    fontWeight: '800',
  },
  companyRow: {
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderColor: '#dce5e4',
    borderRadius: 8,
    borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    padding: 14,
  },
  companyName: {
    color: '#102a43',
    fontSize: 15,
    fontWeight: '800',
  },
  companyMeta: {
    color: '#6b7280',
    fontSize: 13,
    marginTop: 3,
  },
  department: {
    color: '#126f72',
    fontSize: 12,
    fontWeight: '900',
  },
  listContent: {
    paddingBottom: 24,
  },
  errorText: {
    color: '#b42318',
    fontSize: 14,
    marginBottom: 10,
  },
});
