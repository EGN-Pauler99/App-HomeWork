import { Image, Pressable, StyleSheet, Text, View } from 'react-native';

export default function UserCard({ user, expanded, onPress }) {
  const fullName = `${user.firstName} ${user.lastName}`;
  const address = [
    user.address?.address,
    user.address?.city,
    user.address?.state,
  ]
    .filter(Boolean)
    .join(', ');

  return (
    <Pressable
      style={({ pressed }) => [
        styles.card,
        expanded && styles.cardExpanded,
        pressed && styles.cardPressed,
      ]}
      onPress={onPress}
    >
      <View style={styles.summaryRow}>
        <View style={styles.avatarWrap}>
          <Image source={{ uri: user.image }} style={styles.avatar} />
        </View>

        <View style={styles.summaryText}>
          <View style={styles.nameRow}>
            <Text style={styles.name} numberOfLines={1}>
              {fullName}
            </Text>
            <Text style={styles.ageBadge}>{user.age}</Text>
          </View>
          <Text style={styles.info} numberOfLines={1}>
            {user.email}
          </Text>
          <Text style={styles.info} numberOfLines={1}>
            {user.phone}
          </Text>
        </View>

        <Text style={styles.chevron}>{expanded ? 'Less' : 'More'}</Text>
      </View>

      <View style={styles.chipRow}>
        <Text style={styles.chip}>{user.gender}</Text>
        <Text style={styles.chip}>{user.company?.department || 'Team'}</Text>
      </View>

      {expanded ? (
        <View style={styles.detailBox}>
          <View style={styles.detailGrid}>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Age</Text>
              <Text style={styles.detailValue}>{user.age}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Gender</Text>
              <Text style={styles.detailValue}>{user.gender}</Text>
            </View>
          </View>

          <Text style={styles.detailLabel}>Address</Text>
          <Text style={styles.detail}>{address}</Text>

          <Text style={styles.detailLabel}>Company</Text>
          <Text style={styles.detail}>{user.company?.name}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderColor: '#dce5e4',
    borderRadius: 8,
    borderWidth: 1,
    marginBottom: 12,
    padding: 14,
  },
  cardExpanded: {
    borderColor: '#126f72',
  },
  cardPressed: {
    opacity: 0.86,
  },
  summaryRow: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  avatarWrap: {
    backgroundColor: '#d8f1ee',
    borderRadius: 34,
    marginRight: 12,
    padding: 3,
  },
  avatar: {
    backgroundColor: '#edf5f4',
    borderRadius: 30,
    height: 60,
    width: 60,
  },
  summaryText: {
    flex: 1,
    minWidth: 0,
  },
  nameRow: {
    alignItems: 'center',
    flexDirection: 'row',
    marginBottom: 4,
  },
  name: {
    color: '#102a43',
    flex: 1,
    fontSize: 17,
    fontWeight: '900',
  },
  ageBadge: {
    backgroundColor: '#eef7f6',
    borderRadius: 7,
    color: '#126f72',
    fontSize: 12,
    fontWeight: '900',
    marginLeft: 8,
    overflow: 'hidden',
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  info: {
    color: '#5f6c7b',
    fontSize: 13,
    marginBottom: 2,
  },
  chevron: {
    color: '#126f72',
    fontSize: 12,
    fontWeight: '900',
    marginLeft: 8,
  },
  chipRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  chip: {
    backgroundColor: '#f1f5f9',
    borderRadius: 7,
    color: '#475569',
    fontSize: 12,
    fontWeight: '700',
    overflow: 'hidden',
    paddingHorizontal: 9,
    paddingVertical: 5,
    textTransform: 'capitalize',
  },
  detailBox: {
    borderTopColor: '#dce5e4',
    borderTopWidth: 1,
    marginTop: 12,
    paddingTop: 12,
  },
  detailGrid: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 10,
  },
  detailItem: {
    backgroundColor: '#f4f7f6',
    borderRadius: 8,
    flex: 1,
    padding: 10,
  },
  detailLabel: {
    color: '#126f72',
    fontSize: 12,
    fontWeight: '900',
    marginBottom: 3,
    textTransform: 'uppercase',
  },
  detailValue: {
    color: '#102a43',
    fontSize: 15,
    fontWeight: '800',
  },
  detail: {
    color: '#334155',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 10,
  },
});
