import { StyleSheet, Text, View } from 'react-native';

export default function StatCard({ label, value, tone = 'teal' }) {
  return (
    <View style={[styles.card, styles[tone]]}>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.label}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 8,
    flex: 1,
    minHeight: 86,
    padding: 14,
  },
  teal: {
    backgroundColor: '#d8f1ee',
  },
  blue: {
    backgroundColor: '#dbeafe',
  },
  rose: {
    backgroundColor: '#ffe4e6',
  },
  value: {
    color: '#102a43',
    fontSize: 26,
    fontWeight: '900',
  },
  label: {
    color: '#425466',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 6,
  },
});
