import { Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import InfoScreen from '../screen/InfoScreen';
import UserDirectoryScreen from '../screen/UserDirectoryScreen';
import UserStatsScreen from '../screen/UserStatsScreen';

const Tab = createBottomTabNavigator();

function TabIcon({ focused, label }) {
  return (
    <Text style={[styles.tabIcon, focused && styles.tabIconActive]}>
      {label}
    </Text>
  );
}

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: '#126f72',
          tabBarInactiveTintColor: '#7a8699',
          tabBarLabelStyle: styles.tabLabel,
          tabBarStyle: styles.tabBar,
        }}
      >
        <Tab.Screen
          name="Users"
          component={UserDirectoryScreen}
          options={{
            tabBarIcon: ({ focused }) => <TabIcon focused={focused} label="U" />,
          }}
        />
        <Tab.Screen
          name="Stats"
          component={UserStatsScreen}
          options={{
            tabBarIcon: ({ focused }) => <TabIcon focused={focused} label="S" />,
          }}
        />
        <Tab.Screen
          name="Info"
          component={InfoScreen}
          options={{
            tabBarIcon: ({ focused }) => <TabIcon focused={focused} label="I" />,
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: '#ffffff',
    borderTopColor: '#dce5e4',
    height: 68,
    paddingBottom: 10,
    paddingTop: 8,
  },
  tabLabel: {
    fontSize: 12,
    fontWeight: '700',
  },
  tabIcon: {
    backgroundColor: '#edf5f4',
    borderRadius: 14,
    color: '#7a8699',
    fontSize: 12,
    fontWeight: '800',
    height: 28,
    lineHeight: 28,
    overflow: 'hidden',
    textAlign: 'center',
    width: 28,
  },
  tabIconActive: {
    backgroundColor: '#126f72',
    color: '#ffffff',
  },
});
