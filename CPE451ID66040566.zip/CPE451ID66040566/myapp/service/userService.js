const USERS_API_URL = 'https://dummyjson.com/users';

export async function getUsers() {
  const response = await fetch(USERS_API_URL);

  if (!response.ok) {
    throw new Error('Unable to load users');
  }

  const data = await response.json();
  return data.users || [];
}
